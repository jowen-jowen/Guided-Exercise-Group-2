package com.example.appdet_firstge;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText name, age;
    TextView result;
    Button click;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        name = findViewById(R.id.etNameGE1);
        age = findViewById(R.id.etAgeGE1);
        result = findViewById(R.id.tvResultsGE1);
        click = findViewById(R.id.btnClickGE1);


        click.setOnClickListener(v -> {
            result.setText(String.format("Name: %s\nAge: %s", name.getText().toString(), age.getText().toString()));
            name.setText("");
            age.setText("");
            name.requestFocus();
        });
    }

    public void showResultAnotherWay(View view){
        result.setText(String.format("Name: %s\nAge: %s", name.getText().toString(), age.getText().toString()));
        name.setText("");
        age.setText("");
        name.requestFocus();
    }

}